package src;

public class Song {
        double popularity;
        double duration;

        public Song(double popularity, double duration) {
            this.popularity = popularity;
            this.duration = duration;
        }
        
    }

