class Knapsack:
    @staticmethod
    def knapsack(songs, max_duration):
        num_songs = len(songs)
        selected_songs = []
        # Knapsack algorithm implementation
        # ... (use the previously provided knapsack function here)
        return selected_songs  # Return selected songs based on knapsack algorithm
