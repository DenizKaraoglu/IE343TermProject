class Song:
    def __init__(self, popularity, duration):
        self.popularity = popularity
        self.duration = duration
